# -*- coding: utf-8 -*-
"""
av_text_convert.py

サクラエディタの長いマクロを置き換える用スクリプト。

・記号／空白の正規化
・F**K -> FUCK（それ以外の半角 * は全角 ＊ に）
・Windows 禁止文字 (\ / : * ? " < > |) を全角記号に変換
・別名 → display への統一（aliases.csv で管理）
・DB(aliases.csv) に登録されている名前は、出現位置でスペース区切りになるよう分割
・同じ名前（display 含む）は 1 回だけに整理
・CSVに未登録の名前は old だけの行として追記（1 行目の単語は除外）
・「短い名(本名)」「本名(短い名)」「(短い名)本名」からエイリアスを自動生成
・行全体が同じ文字列 2 回なら 1 回に圧縮（初愛ねんね初愛ねんね など）
・最終的に 1 行にまとめて出力

★仕様
  - 出力ファイルは常に SJIS(cp932)
  - 出力は 1 行のみで、行末に '\n' を付ける
    → Windows のテキスト書き込みで CRLF に変換される
"""

import sys
import csv
import re
from pathlib import Path

# 一応、Windows の 255 文字制限対策で少し余裕をとっておく
MAX_FILENAME_LEN = 240


# ===================== 基本 I/O =====================

def read_text_with_fallback(path: Path):
    """テキストファイルを utf-8 → cp932 の順に試して読む。"""
    for enc in ("utf-8", "cp932"):
        try:
            with path.open("r", encoding=enc) as f:
                text = f.read()
            return text, enc
        except UnicodeDecodeError:
            continue
    raise RuntimeError("input ファイルの文字コードを utf-8 / cp932 で読めませんでした。")


def load_aliases(csv_path: Path):
    """aliases.csv からエイリアス定義を読み込む。形式: old,new,display"""
    aliases = []

    if not csv_path.exists():
        return aliases

    with csv_path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            old = (row.get("old") or "").strip()
            new = (row.get("new") or "").strip()
            disp = (row.get("display") or "").strip()

            if not old and not new and not disp:
                continue

            names = set()
            if old:
                names.add(old)
            if new:
                names.add(new)

            if not disp:
                if new and old:
                    disp = f"{old}({new})"
                elif new:
                    disp = new
                elif old:
                    disp = old

            aliases.append((names, disp))

    return aliases


def build_alias_helpers(aliases):
    """
    - alias_names_sorted: スペース挿入に使う「名前一覧」（長さ順ソート）
    - name_to_display : トークン → display のマップ
    - known_tokens    : old/new と display の全部
    """
    alias_names_set = set()
    name_to_display = {}
    display_set = set()

    for names, disp in aliases:
        display_set.add(disp)
        for name in names:
            if not name:
                continue
            alias_names_set.add(name)
            if name not in name_to_display:
                name_to_display[name] = disp

    alias_names_sorted = sorted(alias_names_set, key=len, reverse=True)
    known_tokens = alias_names_set | display_set
    return alias_names_sorted, name_to_display, known_tokens


# ===================== 前処理系 =====================

def insert_spaces_for_aliases(text: str, alias_names_sorted):
    """
    DB 登録名の直後にスペースを挿入して、連結された名前列を切り分ける。
    ただし、カッコ隣接（みひな(永井みひな), (みひな)永井みひな 等）は対象外。
    """
    for name in alias_names_sorted:
        pattern = re.compile(
            rf'(?<![\(\（]){re.escape(name)}(?![\)\）\(\（])'
        )
        text = pattern.sub(name + " ", text)
    return text


def unify_aliases(text: str, name_to_display):
    """old/new を display に統一。"""
    tokens = text.split()
    unified = [name_to_display.get(tok, tok) for tok in tokens]
    return " ".join(unified)


def dedupe_space_separated_tokens(text: str):
    """スペース区切りのトークン重複を削除。"""
    tokens = text.split()
    seen = set()
    out = []
    for tok in tokens:
        if tok not in seen:
            seen.add(tok)
            out.append(tok)
    return " ".join(out)


def sanitize_for_windows_filename(name: str) -> str:
    """
    Windows のファイル名に使えない文字を全角記号に変換し、
    制御文字と末尾の空白・ピリオドを削り、
    最後に MAX_FILENAME_LEN で丸める。
    """
    trans = str.maketrans({
        '\\': '＼',
        '/': '／',
        ':': '：',
        '*': '＊',
        '?': '？',
        '"': '”',
        '<': '＜',
        '>': '＞',
        '|': '｜',
    })
    name = name.translate(trans)
    # 制御文字を削除
    name = re.sub(r'[\x00-\x1F]', '', name)
    # 末尾のスペース・ピリオドは禁止なので削る
    name = name.rstrip(" .")
    # 長すぎる場合は前側だけ残して丸める
    if len(name) > MAX_FILENAME_LEN:
        name = name[:MAX_FILENAME_LEN]
    return name


def normalize_and_tokenize(raw: str, alias_names_sorted, name_to_display):
    """
    1ブロック分のテキストに対して、整形～別名統一～重複削除までを実施。
    戻り値: (整形後テキスト, トークンリスト)
    """
    text = raw.strip()

    # ★追加: 全角カッコを半角に統一
    text = text.replace("（", "(").replace("）", ")")

    # 記号系をまずスペース扱いに
    text = text.replace("／", " ")
    text = text.replace("】・【", " ")

    # 改行もスペースに寄せる
    text = text.replace("\r\n", " ")
    text = text.replace("\r", " ")
    text = text.replace("\n", " ")

    # その他の正規化
    text = text.replace("/", " ")
    text = text.replace(":", "：")
    text = text.replace("    ", " ")
    text = text.replace(", ", " ")
    text = text.replace(".", "")
    text = text.replace("　", " ")

    # DB にある名前で分割
    text = insert_spaces_for_aliases(text, alias_names_sorted)

    # 別名 → display に統一
    text = unify_aliases(text, name_to_display)

    # 特例: F**K → FUCK（このときだけ * を消す）
    text = text.replace("F**K", "FUCK")
    # それ以外の半角 * はすべて全角 ＊ にする
    text = text.replace("*", "＊")

    # カンマは区切りとみなす
    text = text.replace(",", " ")

    # 余計なスペース整理
    text = text.strip()
    text = re.sub(r"[ ]+", " ", text)

    # 同じトークンの重複削除
    text = dedupe_space_separated_tokens(text)

    tokens = text.split()
    return text, tokens


def detect_alias_pairs_in_raw(raw_text: str):
    """
    生テキストから「名前(名前)」「(名前)名前」パターンを検出して (name1, name2) の組で返す。
    半角 / 全角カッコどちらも対象。
    """
    pat1 = re.compile(
        r"([^\s()（）]+?)[ \t]*[\(\（][ \t]*([^\(\)（）]+?)[ \t]*[\)\）]"
    )
    pat2 = re.compile(
        r"[\(\（][ \t]*([^\(\)（）]+?)[ \t]*[\)\）][ \t]*([^\s()（）]+)"
    )

    pairs = []

    # 例: みひな(永井みひな)
    for m in pat1.finditer(raw_text):
        a = m.group(1).strip()
        b = m.group(2).strip()
        if a and b:
            pairs.append((a, b))

    # 例: (みひな)永井みひな
    for m in pat2.finditer(raw_text):
        a = m.group(1).strip()
        b = m.group(2).strip()
        if a and b:
            pairs.append((a, b))

    return pairs


def dedupe_line_full_repeat(raw_text: str) -> str:
    """
    山田まりあ山田まりあ → 山田まりあ
    みたいな「行全体が同じ文字列2回」を圧縮。
    空白やカッコを含む行はスルー。
    """
    lines = raw_text.splitlines()
    out_lines = []

    for line in lines:
        s = line.strip()
        if not s:
            out_lines.append(line)
            continue

        # 空白を含む行は対象外
        if re.search(r"\s", s):
            out_lines.append(line)
            continue

        # カッコや記号を含む行も対象外
        if any(ch in s for ch in "()（）／【】"):
            out_lines.append(line)
            continue

        # 完全に同じ文字列が 2 回続く場合だけ圧縮
        n = len(s)
        if n % 2 == 0:
            half = s[: n // 2]
            if half * 2 == s:
                out_lines.append(half)
                continue

        out_lines.append(line)

    return "\n".join(out_lines)


# ===================== 変換のメインロジック =====================

def convert_text(raw_text: str, aliases, first_line_raw: str):
    """
    全体を整形して 1 行テキストを返す。
    返り値:
      final_text（末尾に '\n' 付き → 実体は CRLF）
      new_names  （新規検出名）
      alias_pairs（パターンから見つけた別名ペア）
    """
    alias_names_sorted, name_to_display, known_tokens = build_alias_helpers(aliases)

    _, tokens = normalize_and_tokenize(
        raw_text, alias_names_sorted, name_to_display
    )

    # 1行目は CSV 登録対象外（タイトル想定）
    first_line_tokens = set()
    if first_line_raw:
        _, first_tokens = normalize_and_tokenize(
            first_line_raw, alias_names_sorted, name_to_display
        )
        first_line_tokens = set(first_tokens)

    # () パターンから別名ペア抽出
    alias_pairs = detect_alias_pairs_in_raw(raw_text)
    alias_pair_names = set()
    for a, b in alias_pairs:
        alias_pair_names.add(a)
        alias_pair_names.add(b)

    # 新規名を洗い出し
    new_names = []
    seen_new = set()
    for tok in tokens:
        if any(ch in tok for ch in "()（）"):
            continue
        if tok in known_tokens:
            continue
        if tok in first_line_tokens:
            continue
        if tok in alias_pair_names:
            continue
        if tok in seen_new:
            continue
        seen_new.add(tok)
        new_names.append(tok)

    # ベース名を組み立て → Windows 用にサニタイズ（長さ丸め込み込み）
    base_line = " ".join(tokens)
    base_line = sanitize_for_windows_filename(base_line)

    # ★ここですでに .mp4 を付与する
    if not base_line.endswith(".mp4"):
        base_line += ".mp4"

    # 行末に '\n' を付ける（Windows では CRLF になる）
    final_text = base_line + "\n"

    return final_text, new_names, alias_pairs


# ===================== CSV 更新 =====================

def append_new_names_to_csv(csv_path: Path, new_names):
    """新規検出名を aliases.csv に追記（old だけの行）。"""
    if not new_names:
        return

    unique = []
    seen = set()
    for n in new_names:
        if n not in seen:
            seen.add(n)
            unique.append(n)

    if csv_path.exists():
        mode = "a"
        write_header = False
    else:
        mode = "w"
        write_header = True

    with csv_path.open(mode, encoding="utf-8-sig", newline="") as f:
        fieldnames = ["old", "new", "display"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        if write_header:
            writer.writeheader()
        for name in unique:
            writer.writerow({"old": name, "new": "", "display": ""})


def update_alias_pairs_in_csv(csv_path: Path, alias_pairs):
    """
    () から検出した別名ペアで aliases.csv を更新。
    ・old が既存ならその行の new を埋める
    ・どちらもなければ、短い方を old として new を追加
    """
    if not alias_pairs:
        return

    unique_pairs = []
    seen_keys = set()
    for a, b in alias_pairs:
        a = a.strip()
        b = b.strip()
        if not a or not b:
            continue
        key = tuple(sorted((a, b)))
        if key not in seen_keys:
            seen_keys.add(key)
            unique_pairs.append((a, b))

    rows = []
    fieldnames = ["old", "new", "display"]

    if csv_path.exists():
        with csv_path.open("r", encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f)
            if reader.fieldnames:
                fieldnames = reader.fieldnames
            for row in reader:
                rows.append(
                    {
                        "old": (row.get("old") or "").strip(),
                        "new": (row.get("new") or "").strip(),
                        "display": (row.get("display") or "").strip(),
                    }
                )

    # old → 行インデックス
    index_by_old = {}
    for i, row in enumerate(rows):
        old = row.get("old", "")
        if old and old not in index_by_old:
            index_by_old[old] = i

    def decide_old_new(a: str, b: str):
        """どちらを old/new にするか決める。"""
        in_a = a in index_by_old
        in_b = b in index_by_old

        if in_a and not in_b:
            return a, b
        if in_b and not in_a:
            return b, a

        # DB に無い場合は短い方を old にする
        if len(a) < len(b):
            return a, b
        if len(b) < len(a):
            return b, a

        # 長さ同じならそのまま
        return a, b

    for a, b in unique_pairs:
        old_name, new_name = decide_old_new(a, b)

        if old_name in index_by_old:
            row = rows[index_by_old[old_name]]
            current_new = row.get("new", "")
            if not current_new or current_new == new_name:
                row["new"] = new_name
            else:
                # 衝突したらとりあえず新しい方で上書き
                row["new"] = new_name
        else:
            rows.append({"old": old_name, "new": new_name, "display": ""})
            index_by_old[old_name] = len(rows) - 1

    with csv_path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(
                {
                    "old": row.get("old", ""),
                    "new": row.get("new", ""),
                    "display": row.get("display", ""),
                }
            )


# ===================== main =====================

def main():
    if len(sys.argv) < 2:
        print("使い方: python av_text_convert.py input.txt")
        sys.exit(1)

    input_path = Path(sys.argv[1])
    if not input_path.exists():
        print(f"入力ファイルが見つかりません: {input_path}")
        sys.exit(1)

    script_dir = Path(__file__).resolve().parent
    aliases_csv = script_dir / "aliases.csv"

    # 入力文字コードはそのまま保持（表示用）
    text, input_encoding = read_text_with_fallback(input_path)

    # 行全体が 2 回重複しているものを圧縮
    preprocessed = dedupe_line_full_repeat(text)

    # 1 行目（タイトル）は CSV 登録対象外
    lines = preprocessed.splitlines()
    if lines:
        first_line_raw = lines[0]
    else:
        first_line_raw = ""

    aliases = load_aliases(aliases_csv)

    converted, new_names, alias_pairs = convert_text(
        preprocessed, aliases, first_line_raw
    )

    output_path = input_path.with_name(
        input_path.stem + "_converted" + input_path.suffix
    )

    # 出力は SJIS 固定。SJIS に無い文字は消して書く。
    # newline を指定しないので、'\n' は Windows 上で CRLF に変換される。
    with output_path.open("w", encoding="cp932") as f:
        f.write(converted.encode("cp932", errors="ignore").decode("cp932"))

    # CSV 更新（()パターン → new、未知の名前 → old 追加）
    update_alias_pairs_in_csv(aliases_csv, alias_pairs)
    append_new_names_to_csv(aliases_csv, new_names)

    print(f"変換完了: {output_path} （input: {input_encoding}, output: cp932, CRLF）")


if __name__ == "__main__":
    main()
