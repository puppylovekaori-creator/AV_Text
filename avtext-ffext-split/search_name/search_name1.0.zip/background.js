'use strict';

const HOST_NAME = 'avtext_helper';

// req_id -> resolver
const pending = new Map();

let port = null;
function ensurePort() {
  if (port) return port;

  port = browser.runtime.connectNative(HOST_NAME);

  port.onMessage.addListener((resp) => {
    try {
      const reqId = resp && resp.req_id;
      if (!reqId) return;

      const resolve = pending.get(reqId);
      if (!resolve) return;

      pending.delete(reqId);
      resolve(resp);
    } catch (e) {
      // ignore
    }
  });

  port.onDisconnect.addListener(() => {
    // 全pendingをエラーで解放（content側は「表示しない」扱い）
    for (const [reqId, resolve] of pending.entries()) {
      resolve({ status: 'error', target: 'check_actress', req_id: reqId, error: 'native host disconnected' });
    }
    pending.clear();
    port = null;
  });

  return port;
}

function nextReqId() {
  // 1..2^31-1
  return (Math.floor(Math.random() * 0x7fffffff) + 1) | 0;
}

browser.runtime.onMessage.addListener((msg, sender) => {
  if (!msg || msg.type !== 'check_actress') return;

  const text = (msg.text || '');
  const reqId = msg.req_id || nextReqId();

  const p = new Promise((resolve) => {
    pending.set(reqId, resolve);

    // タイムアウト（遅延が大きい場合は結果を捨てる）
    setTimeout(() => {
      if (pending.has(reqId)) {
        pending.delete(reqId);
        resolve({ status: 'error', target: 'check_actress', req_id: reqId, error: 'timeout' });
      }
    }, 1500);

    try {
      const p = ensurePort();
      p.postMessage({ target: 'check_actress', text, req_id: reqId });
    } catch (e) {
      pending.delete(reqId);
      resolve({ status: 'error', target: 'check_actress', req_id: reqId, error: String(e) });
    }
  });

  return p;
});
