'use strict';

const MAX_LEN = 12;      // 正規化後の最大文字数
const DEBOUNCE_MS = 120; // 選択が落ち着くのを待つ

let timer = null;
let overlayEl = null;
let lastReqToken = 0;   // 返答の取り違え防止
let lastText = '';      // 同一選択の無駄撃ち防止
const cache = new Map(); // text -> found(true/false)

const EDGE_CHARS = new Set([
  '、','。','，','．',',','.',
  '!','！','?','？',':','：',';','；',
  '"','“','”',"'",'‘','’',
  '「','」','『','』',
  '（','）','(',')',
  '[',']','【','】',
  '<','>','＜','＞','《','》','〔','〕'
]);

function codePointLength(s) {
  return [...s].length;
}

function trimSpaces(s) {
  return s.replace(/^[\s\u3000]+|[\s\u3000]+$/g, '');
}

function stripEdgePunct(s) {
  while (s && EDGE_CHARS.has(s[0])) s = s.slice(1);
  while (s && EDGE_CHARS.has(s[s.length - 1])) s = s.slice(0, -1);
  return s;
}

function normalizeSelection(raw) {
  if (!raw) return '';
  let s = raw;

  // 前後空白
  s = trimSpaces(s);

  // 前後の記号を削る（中身の「・」「ー」は残す）
  s = stripEdgePunct(s);
  s = trimSpaces(s);

  return s;
}

function isSingleToken(s) {
  // 中に空白/改行があればNG（IN非対応）
  return !/[\s\u3000]/.test(s);
}

function getSelectionText() {
  const sel = window.getSelection();
  if (!sel) return { text: '', rect: null, collapsed: true };

  const collapsed = sel.isCollapsed || sel.toString() === '';
  if (collapsed) return { text: '', rect: null, collapsed: true };

  const text = sel.toString();

  // 位置取得（最初のrangeのrect）
  let rect = null;
  try {
    if (sel.rangeCount > 0) {
      const range = sel.getRangeAt(0);
      const r = range.getBoundingClientRect();
      if (r && (r.width || r.height)) {
        rect = r;
      } else {
        const rects = range.getClientRects();
        if (rects && rects.length > 0) rect = rects[0];
      }
    }
  } catch (e) {
    rect = null;
  }

  return { text, rect, collapsed: false };
}

function ensureOverlay() {
  if (overlayEl) return overlayEl;

  overlayEl = document.createElement('div');
  overlayEl.id = 'avtext-actress-check';
  overlayEl.style.position = 'fixed';
  overlayEl.style.zIndex = '2147483647';
  overlayEl.style.padding = '6px 10px';
  overlayEl.style.borderRadius = '8px';
  overlayEl.style.fontSize = '14px';
  overlayEl.style.lineHeight = '1.2';
  overlayEl.style.boxShadow = '0 6px 18px rgba(0,0,0,0.25)';
  overlayEl.style.border = '1px solid rgba(0,0,0,0.15)';
  overlayEl.style.background = 'rgba(255,255,255,0.96)';
  overlayEl.style.color = '#111';
  overlayEl.style.userSelect = 'none';
  overlayEl.style.pointerEvents = 'none';

  document.documentElement.appendChild(overlayEl);
  return overlayEl;
}

function hideOverlay() {
  if (!overlayEl) return;
  overlayEl.remove();
  overlayEl = null;
}

function positionOverlay(rect) {
  if (!overlayEl || !rect) return;

  const margin = 10;
  let x = rect.left;
  let y = rect.top - margin;

  // 画面外に出ない程度に調整
  x = Math.max(8, Math.min(x, window.innerWidth - 8));
  y = Math.max(8, Math.min(y, window.innerHeight - 8));

  overlayEl.style.left = `${x}px`;
  overlayEl.style.top = `${y}px`;
}

async function checkAndShow(normText, rect, token) {
  // キャッシュ
  if (cache.has(normText)) {
    if (token !== lastReqToken) return; // 古い要求は捨てる
    const found = cache.get(normText);
    const el = ensureOverlay();
    el.textContent = found ? '登録済' : '未登録';
    positionOverlay(rect);
    return;
  }

  const resp = await browser.runtime.sendMessage({
    type: 'check_actress',
    text: normText,
    req_id: token
  });

  // 選択が解除されていたら消す（遅延返答の表示防止）
  const sel = window.getSelection();
  if (!sel || sel.isCollapsed) {
    hideOverlay();
    return;
  }

  if (token !== lastReqToken) return; // 古い要求は捨てる

  if (!resp || resp.status !== 'ok' || resp.target !== 'check_actress') {
    // エラー時は「未登録」を出さず、無表示（誤誘導防止）
    return;
  }

  const found = !!resp.found;
  cache.set(normText, found);

  const el = ensureOverlay();
  el.textContent = found ? '登録済' : '未登録';
  positionOverlay(rect);
}

function onSelectionChange() {
  if (timer) clearTimeout(timer);

  timer = setTimeout(async () => {
    timer = null;

    const { text, rect, collapsed } = getSelectionText();

    // 選択解除で消える
    if (collapsed) {
      lastText = '';
      lastReqToken++;
      hideOverlay();
      return;
    }

    const norm = normalizeSelection(text);

    // IN非対応：空白/改行が入るものは無視（表示もしない）
    if (!norm || !isSingleToken(norm)) {
      lastText = '';
      lastReqToken++;
      hideOverlay();
      return;
    }

    const len = codePointLength(norm);
    if (len <= 0 || len > MAX_LEN) {
      lastText = '';
      lastReqToken++;
      hideOverlay();
      return;
    }

    // 同一テキストの連打を抑止（位置だけ更新したいならここを変える）
    if (norm === lastText && overlayEl) {
      positionOverlay(rect);
      return;
    }

    lastText = norm;
    const token = ++lastReqToken;

    await checkAndShow(norm, rect, token);

  }, DEBOUNCE_MS);
}

document.addEventListener('selectionchange', onSelectionChange, { passive: true });
window.addEventListener('blur', () => { hideOverlay(); }, { passive: true });
