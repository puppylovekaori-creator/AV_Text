const menus = browser.menus || browser.contextMenus;

// 1つの親メニューにまとめる（自分の項目の並び順を固定しやすい）
menus.create({
  id: "avtext-parent",
  title: "AVText",
  contexts: ["all"]
});

menus.create({
  id: "avtext-title",
  parentId: "avtext-parent",
  title: "選択文字列を title.txt に送る",
  contexts: ["selection"]
});

menus.create({
  id: "avtext-actress",
  parentId: "avtext-parent",
  title: "選択文字列を actress.txt に送る",
  contexts: ["selection"]
});

menus.create({
  id: "avtext-sep-1",
  parentId: "avtext-parent",
  type: "separator",
  contexts: ["all"]
});

menus.create({
  id: "avtext-focus-sakura",
  parentId: "avtext-parent",
  title: "サクラエディタを前面に",
  contexts: ["all"]
});

menus.onClicked.addListener(async (info) => {
  const hasSel = !!info.selectionText;

  let target = null;
  let text = "";

  if (info.menuItemId === "avtext-title") {
    if (!hasSel) return;
    target = "title";
    text = info.selectionText;
  } else if (info.menuItemId === "avtext-actress") {
    if (!hasSel) return;
    target = "actress";
    text = info.selectionText;
  } else if (info.menuItemId === "avtext-focus-sakura") {
    target = "focus_sakura";
  } else {
    return;
  }

  try {
    await browser.runtime.sendNativeMessage("avtext_helper", {
      target,
      text
    });
  } catch (e) {
    console.error("sendNativeMessage failed:", e);
  }
});
