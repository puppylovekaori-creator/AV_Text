// デバッグしやすいようにログ多め版

// runtime.id を起動時に出しておく（allowed_extensions の確認用）
console.log("AV Text Paster background loaded");
console.log("runtime.id =", browser.runtime.id);

const menus = browser.menus || browser.contextMenus;

menus.create({
  id: "avtext-title",
  title: "選択文字列を title.txt に送る",
  contexts: ["selection"]
});

menus.create({
  id: "avtext-actress",
  title: "選択文字列を actress.txt に送る",
  contexts: ["selection"]
});

// クリック時のフック
menus.onClicked.addListener(async (info, tab) => {
  console.log("menus.onClicked fired:", {
    menuItemId: info.menuItemId,
    hasSelection: !!info.selectionText,
    selectionPreview: (info.selectionText || "").slice(0, 40)
  });

  if (!info.selectionText) {
    console.warn("no selectionText, abort");
    return;
  }

  const target =
    info.menuItemId === "avtext-title" ? "title" :
    info.menuItemId === "avtext-actress" ? "actress" :
    null;

  console.log("resolved target =", target);

  if (!target) {
    console.warn("unknown menuItemId:", info.menuItemId);
    return;
  }

  try {
    console.log("sendNativeMessage start");
    const resp = await browser.runtime.sendNativeMessage("avtext_helper", {
      target: target,
      text: info.selectionText
    });
    console.log("sendNativeMessage response:", resp);
  } catch (e) {
    console.error("sendNativeMessage failed:", e);
  }
});
